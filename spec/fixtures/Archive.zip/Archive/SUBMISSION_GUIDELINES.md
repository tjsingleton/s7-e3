Fork this repository and hack away! When you are ready for a review, log into
the RMU web app and request a review for the appropriate exercise. You can
do this as often as you'd like, a general rule of thumb is to request feedback
early and often.

Other students in the session will be able to see your code on github, and it's
okay to collaborate as long as the work you submit is mostly of your own
creation. That said, do not share your solution or the problem description
with anyone outside of the session without talking to me about it first. I
will not share your submission with anyone outside of your session except
RMU staff without your permission.

NOTE: No work done after 5/30 will be evaluated, be sure to request an initial 
review way before then!
